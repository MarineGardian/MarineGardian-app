library(testthat)
library(testPakcages)

test_check("testPakcages")
