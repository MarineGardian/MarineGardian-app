## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(ggplot2) 

## ----setup--------------------------------------------------------------------
library(testPakcages)

## ----example-grahespackeges---------------------------------------------------
# Exemple d'utilisation de la fonction grahespackeges
library(testPakcages)
data <- iris
grahespackeges(data = data, x = "Sepal.Length", y = "Sepal.Width", 
                  group_by = "Species", color_by = "Species", plot_type = "curve")


